class Constants{
  static const ENTER_MOBILE_TITLE="Enter phone number to continue";
  static const ENTER_OTP_TITLE="Enter OTP to continue";
  static const HINT_TEXT='Phone number (+xx xxx-xxx-xxxx)';
  static const OTP_HINT_TEXT='Enter OTP';
  static const LOGIN='LOGIN';
  static const CONFIRM='CONFIRM';
  static const FAILED_TO_VERIFY_PN="Failed to Verify Phone Number:";
  static const VERIFICATION_CODE="verification code: ";
  ///routes
  ///Routes
  static const INITIAL_ROUTE = '/';
  static const OTP_PAGE = '/otp_page';
  static const HOME_PAGE = '/home_page';
}