import 'package:flutter/material.dart';
import 'package:otp_auth/pages/home_page.dart';
import 'package:otp_auth/pages/login_page.dart';
import 'package:otp_auth/pages/otp_page.dart';

import 'constants.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    final String args = settings.arguments;
    switch (settings.name) {
      case Constants.INITIAL_ROUTE:
        return MaterialPageRoute(
          builder: (_) => LoginPage(),
        );
        break;
      case Constants.OTP_PAGE:
        return MaterialPageRoute(
          builder: (_) => OtpPage(id: args,),
        );
      case Constants.HOME_PAGE:
        return MaterialPageRoute(
          builder: (_) => HomePage(),
        );
    }
  }
}
