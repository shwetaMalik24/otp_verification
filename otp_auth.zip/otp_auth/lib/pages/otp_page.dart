import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:otp_auth/base_class.dart';
import 'package:otp_auth/utils/constants.dart';
import 'package:otp_auth/widgets/button.dart';
import 'package:sms_autofill/sms_autofill.dart';

class OtpPage extends StatelessWidget with BaseClass {
  final id;
  OtpPage({Key key,@required this.id}) : super(key: key);
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _smsController = TextEditingController();

  final SmsAutoFill _autoFill = SmsAutoFill();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      key: _scaffoldKey,
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(Constants.ENTER_OTP_TITLE,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w500)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _smsController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: Constants.OTP_HINT_TEXT),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Button(
                title: Constants.CONFIRM,
                onPressed: () {
                  signInWithPhoneNumber(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void signInWithPhoneNumber(BuildContext context) async {
    try {
      final AuthCredential credential = PhoneAuthProvider.credential(
        verificationId: id,
        smsCode: _smsController.text,
      );
      final User user = (await _auth.signInWithCredential(credential)).user;
      Navigator.pushNamed(context, Constants.HOME_PAGE);
    } catch (e) {
      showSnackbar(Constants.FAILED_TO_VERIFY_PN + e.toString(),_scaffoldKey);
    }
  }
}
