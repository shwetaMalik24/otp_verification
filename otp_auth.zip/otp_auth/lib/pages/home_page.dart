import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:otp_auth/utils/constants.dart';


class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(Constants.HOME_PAGE),
        ],
      ),
    );
  }
}
