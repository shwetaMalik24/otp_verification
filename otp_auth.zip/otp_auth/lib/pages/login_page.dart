import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:otp_auth/base_class.dart';
import 'package:otp_auth/utils/constants.dart';
import 'package:otp_auth/widgets/button.dart';

class LoginPage extends StatelessWidget with BaseClass {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final TextEditingController _phoneNumberController = TextEditingController();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      key: _scaffoldKey,
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(Constants.ENTER_MOBILE_TITLE,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w500)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _phoneNumberController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: Constants.HINT_TEXT),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Button(
                title: Constants.LOGIN,
                onPressed: () {
                  verifyPhoneNumber(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void verifyPhoneNumber(BuildContext context) async {
    PhoneVerificationCompleted verificationCompleted =
        (PhoneAuthCredential phoneAuthCredential) async {
      showSnackbar(
          "Phone number automatically verified and user signed in: ${_auth.currentUser.uid}",
          _scaffoldKey);
    };
    //Listens for errors with verification, such as too many attempts
    PhoneVerificationFailed verificationFailed =
        (FirebaseAuthException authException) {
      showSnackbar(
          'Phone number verification failed. Code: ${authException.code}. Message: ${authException.message}',
          _scaffoldKey);
    };
    //Callback for when the code is sent
    PhoneCodeSent codeSent =
        (String verificationId, [int forceResendingToken]) async {
      Navigator.pushNamed(context, Constants.OTP_PAGE,
          arguments: verificationId);
    };
    PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
        (String verificationId) {
      showSnackbar(Constants.VERIFICATION_CODE + verificationId, _scaffoldKey);
    };
    try {
      await _auth
          .verifyPhoneNumber(
              phoneNumber: _phoneNumberController.text,
              timeout: const Duration(seconds: 50),
              verificationCompleted: verificationCompleted,
              verificationFailed: verificationFailed,
              codeSent: codeSent,
              codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);

    } catch (e) {
      showSnackbar(Constants.FAILED_TO_VERIFY_PN + e, _scaffoldKey);
    }
  }
}
