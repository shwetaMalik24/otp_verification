import 'package:flutter/material.dart';
import 'package:otp_auth/utils/theme.dart';

class Button extends StatelessWidget {
  final title;
  final Function() onPressed;

  Button({Key key, @required this.title, this.onPressed}) : super(key: key);
  final ButtonStyle raisedButtonStyle = ElevatedButton.styleFrom(
    primary: ThemeColor.questionButtonColor,
    minimumSize: Size(200, 36),
    padding: EdgeInsets.symmetric(horizontal: 16),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(2)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: raisedButtonStyle,
      onPressed: onPressed,
      child: Text(title),
    );
  }
}
