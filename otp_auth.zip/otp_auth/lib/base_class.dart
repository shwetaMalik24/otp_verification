import 'package:flutter/material.dart';

mixin BaseClass{
  void showSnackbar(String message,GlobalKey<ScaffoldState> key) {
    key.currentState.showSnackBar(SnackBar(content: Text(message)));
  }
}